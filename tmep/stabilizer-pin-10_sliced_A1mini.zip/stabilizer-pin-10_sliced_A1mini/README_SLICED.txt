SLICED: 10 stabilizer pin variants, Bambu Lab A1 mini
Source: PRINT_ALL_10_A1_MINI.3mf (from stabilizer-pin-10.zip, unchanged; originals in source/)

PRINT THIS FILE:  PRINT_ALL_10_A1_MINI.gcode.3mf
  Bambu Studio: File > Open, then Print plate. Or copy it to the A1 mini's SD card.
  (PRINT_ALL_10_A1_MINI.gcode is the same toolpath as plain G-code, for reference.)

Slicer: Bambu Studio 02.09.01.70 (CLI)
Printer: Bambu Lab A1 mini, 0.4 mm nozzle, Textured PEI plate
Filament: Bambu PLA Basic @BBL A1M (220 C nozzle / 65 C bed)
Process: 0.20mm Standard @BBL A1M with these changes:
  layer height 0.2 mm, 4 walls, 15% sparse infill, no supports, print sequence by layer
Scale 100%, millimetres, no re-arrange and no auto-orient: wide D12 grip on the bed, thin shaft up
Plate: 10 objects (IDs 07 17 27 37 47 / 08 18 28 38 48), max height 42.0 mm, 210 layers
Estimate: about 50 min 40 s, 23.6 g PLA

Before printing: if your plate isn't Textured PEI or your filament isn't Bambu PLA Basic,
open the .gcode.3mf in Bambu Studio, change the plate/filament, and re-slice.
Check the shaft layers in the preview (2.1-2.5 mm shafts print almost solid at 4 walls).
