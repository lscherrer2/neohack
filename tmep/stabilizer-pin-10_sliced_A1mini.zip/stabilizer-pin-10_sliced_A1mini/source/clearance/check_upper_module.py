"""Correct sequence: yoke already fitted, pin locks yoke/horn/motor, upper module next.
Conservative axis-aligned bounds prove separation for a straight +CAD-Z approach.
Does not establish physical fit, arbitrary tilted paths or robot/gripper clearance.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np,trimesh,rhino3dm as rh
ROOT=Path(__file__).resolve().parents[4];sys.path.insert(0,str(ROOT))
from scripts.so101_assets import object_mesh,SHA
from assembly_policy.so101.scene import metadata
from assembly_policy.so101.fastener import AXIS,origins,target_rotations
OUT=Path(__file__).resolve().parent
cad=ROOT/'assets_local/hiwonder/follower.3dm'
assert hashlib.sha256(cad.read_bytes()).hexdigest()==SHA
doc=rh.File3dm.Read(str(cad));meta=metadata();pos=origins(meta);rot=target_rotations(meta)
axis=AXIS*1000;R=rot['yoke'];lift=.6
# Same rigid yaw/lift correction as supporting v14 yoke, carried into upper module.
groups={'upper_motor':list(range(16,30)),'upper_metal_horns':[123,124],
        'next_leg':[139],'upper_leg_fasteners':list(range(140,145))}
meshes={};records=[]
for name,ids in groups.items():
 m=trimesh.util.concatenate([object_mesh(doc.Objects[i]) for i in ids]);m.apply_scale(1000)
 m.vertices=(m.vertices-axis)@R.T+axis+[0,0,lift];meshes[name]=m
 records.append(dict(name=name,indices=ids,object_ids=[str(doc.Objects[i].Attributes.Id) for i in ids],bounds_mm=m.bounds.tolist()))
y=trimesh.load_mesh(ROOT/'assets_local/parts/yoke.obj',process=True);y.vertices=(y.vertices@R.T+pos['yoke'])*1000
angles=np.arange(32)*2*np.pi/32;starts=np.column_stack([axis[0]+2*np.cos(angles),axis[1]+2*np.sin(angles),np.zeros(32)])
hits=y.ray.intersects_location(starts,np.tile([0,0,1],(32,1)))[0];shoulder=float(hits[:,2].max())
report_rows=[]
manifest=json.loads((OUT.parent/'MANIFEST.json').read_text())
for pin in manifest['parts']:
 h=pin['handle_length_mm'];pin_bounds=np.array([[axis[0]-6,axis[1]-6,shoulder-pin['shaft_length_mm']],[axis[0]+6,axis[1]+6,shoulder+h]])
 checks=[]
 for name,m in meshes.items():
  b=m.bounds
  # Upper module only moves upward in CAD Z during approach. Lateral separation
  # persists; any lower-height separation must put the module ABOVE the pin.
  sx=max(b[0,0]-pin_bounds[1,0],pin_bounds[0,0]-b[1,0])
  sy=max(b[0,1]-pin_bounds[1,1],pin_bounds[0,1]-b[1,1])
  sz=b[0,2]-pin_bounds[1,2]
  margins=[sx,sy,sz];best=max(margins)
  assert best>0,(pin['id'],name,margins)
  checks.append(dict(part=name,proven_separation_axis=['CAD X','CAD Y','CAD Z'][int(np.argmax(margins))],conservative_gap_mm=float(best)))
 report_rows.append(dict(id=pin['id'],grip_length_mm=h,shaft_diameter_mm=pin['shaft_diameter_mm'],shaft_length_mm=pin['shaft_length_mm'],pin_bounds_mm=pin_bounds.tolist(),upper_module_clear=True,component_checks=checks))
headroom=float(meshes['next_leg'].bounds[0,2]-shoulder)
report=dict(sequence=['Motor with metal sides/horns prepared','Printed yoke slid onto motor','Pin inserted through already-fitted yoke and horn into motor','Upper motor-and-next-leg module lowered onto the already locked assembly'],
 correction='Earlier yoke-over-pin failure checks tested the wrong assembly step and do not answer this upper-module question.',
 source_cad_sha256=SHA,reference_pose='Full vendor upper assembly; apply same -3 degree CAD-Z yaw and +0.6 mm CAD-Z lift as current yoke. This is the saved vendor leg articulation.',
 approach='Upper module translated down along source CAD Z to its saved final position; all positive approach lifts also clear by the reported bounds.',
 shoulder_z_mm=shoulder,headroom_to_lowest_leg_mm=headroom,nominal_28mm_grip_gap_mm=headroom-28,
 upper_components=records,results=report_rows,
 limits=['Conservative CAD bounding separation, not native dynamic replay or robot execution.',
 'Qualified only for this saved upper-module pose and straight axial approach. Other leg angles/tilts need their own checks.',
 'Pin-to-yoke/horn/motor fit and insertion depth, physical tolerances, gripper access and full module-to-yoke mating are separate checks.'])
(OUT/'UPPER_MODULE_CLEARANCE.json').write_text(json.dumps(report,indent=2)+'\n')
# Local visualization meshes; kept out of the friend print ZIP.
for n,m in meshes.items():m.export(OUT/'upper-assembly'/f'{n}_aligned.obj')
print(json.dumps(dict(count=len(report_rows),all_upper_module_clear=True,headroom_mm=headroom,nominal_gap_mm=headroom-28,upper_components=records),indent=2))
