$fn = 128;

grip_diameter = 12;
grip_length = 28;
shaft_diameter = 2.3;
shaft_length = 14;

union() {
    cylinder(d = grip_diameter, h = grip_length);
    translate([0, 0, grip_length - 0.01])
        cylinder(d = shaft_diameter, h = shaft_length + 0.01);
}
